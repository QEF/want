#ifndef __IOTK_CONFIG_H
#define __IOTK_CONFIG_H

! Type definitions:
#define __IOTK_INTEGER1 4



#define __IOTK_LOGICAL1 4







! End of type definitions


!!
!! NOTE: iotk_configure seems not to be able to detect all
!!       workaround's. We impose them automatically.
!!
#if defined(__XLF)
#   define __IOTK_WORKAROUND5
#   define __IOTK_WORKAROUND9
#elif defined(__INTEL)
#   define __IOTK_WORKAROUND1
#   define __IOTK_WORKAROUND3
#   define __IOTK_WORKAROUND5
#elif defined(__PGI)
#   define __IOTK_WORKAROUND2
#   define __IOTK_WORKAROUND4
#elif defined(__NAG)
#   define __IOTK_WORKAROUND4
#elif defined(__ALPHA)
#   define __IOTK_WORKAROUND1
#   define __IOTK_WORKAROUND6
#elif defined(__SX6)
#   define __IOTK_WORKAROUND5
#   define __IOTK_WORKAROUND7
#endif

!! Workarounds for bugs:
!
!
!
!
!
!
!
!
!

#endif

