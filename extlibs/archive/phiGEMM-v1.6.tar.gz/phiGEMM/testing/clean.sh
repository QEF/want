#!/bin/bash
rm phiGEMM-test-suite.* out-comparative.*
